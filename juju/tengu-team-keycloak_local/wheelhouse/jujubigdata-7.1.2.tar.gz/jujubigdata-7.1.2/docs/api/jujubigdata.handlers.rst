jujubigdata.handlers
====================

.. automembersummary::
    :nosignatures:

    jujubigdata.handlers

.. automodule:: jujubigdata.handlers
    :members:
    :undoc-members:
    :show-inheritance:
