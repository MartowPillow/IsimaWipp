jujubigdata.relations
=====================

.. automembersummary::
    :nosignatures:

    jujubigdata.relations

.. automodule:: jujubigdata.relations
    :members:
    :undoc-members:
    :show-inheritance:
